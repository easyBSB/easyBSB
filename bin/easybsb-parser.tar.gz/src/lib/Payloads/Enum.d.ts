import { Value, Command } from "../interfaces";
export declare class Enum implements Value<number> {
    value: number | null;
    private enum;
    command: Command;
    constructor(data: number[] | string | number | null, command: Command);
    toPayload(): any[];
    toString(lang?: string): string;
}
//# sourceMappingURL=Enum.d.ts.map