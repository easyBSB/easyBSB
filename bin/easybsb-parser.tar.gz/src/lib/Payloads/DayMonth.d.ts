import { Value, Command } from "../interfaces";
export declare class DayMonth implements Value<Date> {
    value: Date | null;
    command: Command;
    constructor(data: number[] | string | Date | null, command: Command);
    toPayload(): any[];
    toString(): string;
}
//# sourceMappingURL=DayMonth.d.ts.map