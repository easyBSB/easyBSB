import { Value, Command, TranslateItem } from "../interfaces";
export declare class Bit implements Value<number> {
    value: number | null;
    enum: TranslateItem | null;
    command: Command;
    constructor(data: number[] | number | string | null, command: Command);
    toPayload(): any[];
    toString(lang?: string): string;
}
//# sourceMappingURL=Bit.d.ts.map