import { Value } from "../interfaces";
export declare class Error implements Value<number> {
    value: number | null;
    constructor(data: number[] | number | string | null);
    toPayload(): any[];
    toString(lang?: string): string;
}
//# sourceMappingURL=Error.d.ts.map