import { Value, Command } from "../interfaces";
export declare class DateTime implements Value<Date> {
    value: Date | null;
    command: Command;
    constructor(data: number[] | string | Date | number | null, command: Command);
    toPayload(): any[];
    toString(): string;
}
//# sourceMappingURL=DateTime.d.ts.map