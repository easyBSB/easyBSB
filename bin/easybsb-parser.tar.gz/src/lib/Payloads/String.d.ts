import { Value, Command } from "../interfaces";
export declare class String implements Value<string> {
    value: string | null;
    command: Command;
    constructor(data: number[] | string | null | number, command: Command);
    toPayload(): any[];
    toString(): string;
}
//# sourceMappingURL=String.d.ts.map