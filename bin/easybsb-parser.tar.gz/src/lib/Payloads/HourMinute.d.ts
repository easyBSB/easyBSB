import { Value, Command } from "../interfaces";
export declare class HourMinute implements Value<Date> {
    value: Date | null;
    command: Command;
    constructor(data: number[] | string | Date | null, command: Command);
    toPayload(): any[];
    toString(): string;
}
//# sourceMappingURL=HourMinute.d.ts.map