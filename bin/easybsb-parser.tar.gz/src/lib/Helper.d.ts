import { TranslateItem } from "./interfaces";
export declare class Helper {
    static getLanguage(langResource: TranslateItem | null | undefined, language?: string): string | null;
    static toHexString(byteArray: number[]): string;
}
//# sourceMappingURL=Helper.d.ts.map