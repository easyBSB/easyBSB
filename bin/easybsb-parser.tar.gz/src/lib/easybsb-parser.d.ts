export declare class BsbCore {
    private connection;
    log(): void;
    private createConnection;
}
//# sourceMappingURL=easybsb-parser.d.ts.map